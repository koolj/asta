package org.bwbc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.gargoylesoftware.htmlunit.javascript.host.Console;
import com.google.gson.Gson;

public class control {
	public WebDriver driver;
	public String webhost_link;
	public List<String> posturl = new ArrayList<>();
	boolean isPresent = true;
	Gson gson = new Gson();
	public String socialgroup;
	public String adcontent;
	public String groupsearch;
	public String patternmatch;
	public String topicsms;
	public String assigneephone;
	public boolean status = false;
	public int numres;
	
@Parameters("browser")
@BeforeTest

	//Passing Browser parameter from TestNG xml
	public void beforeTest(String browser) throws InterruptedException, IOException {
		String chrome_link = "./drivers/chromedriver.exe";
		// If the browser is Chrome, then do this
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver",chrome_link);	
			ChromeOptions options = new ChromeOptions();
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			options.addArguments("--disable-notifications");
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			driver = new ChromeDriver(capabilities);
		} 
	}
@Test	
	public void control () throws IOException, InterruptedException{
	
		try {

			JavascriptExecutor js = (JavascriptExecutor) driver;
			
			//open link facebook group
			//driver.get("https://www.facebook.com/groups/Choque.1102/");
			Thread.sleep(500);
			
			//check db, neu status 1, run
			crawl_getpost("http://45.118.145.34:3000/api/searchcrawl", "POST", "{\"namefield\": \"socialurl\",\"valuefield\": \"facebookgroup\"}");
			Thread.sleep(3000);
			
			//sample 
			//*[starts-with(@class,'_5pcq')]
			//*[contains(@id,'intro_container_id')]
			
			/*
			for(int p=0; !status; p++  ) {
				Thread.sleep(8000);
				System.out.println("-----OFF CRAWLING-----");
				crawl_getpost("http://45.118.145.34:3000/api/searchcrawl", "POST", "{\"namefield\": \"socialurl\",\"valuefield\": \"facebookgroup\"}");
			}
			//check status
			crawl_getpost("http://45.118.145.34:3000/api/searchcrawl", "POST", "{\"namefield\": \"socialurl\",\"valuefield\": \"facebookgroup\"}");
			Thread.sleep(2000);
			if (!status) {
				System.out.println("-----OFF CRAWLING-----");
				break crawling;
			}
			*/
			
			//loop untill status to false
			for(int n=0; status; n++  ) {
				driver.get(socialgroup);
				//login
				//loop until found
				isPresent = true;
				for(int i=0; isPresent; i++  ) {
					//if LOGIN BUTTON found
					if (driver.findElements(By.cssSelector("#loginbutton")).size()>0)
					{	
						driver.findElement(By.xpath("//*[@id=\"email\"]")).clear();
						driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("100024433954363");
						driver.findElement(By.xpath("//*[@id=\"pass\"]")).clear();
						driver.findElement(By.xpath("//*[@id=\"pass\"]")).sendKeys("Bb@5dd212");
						Thread.sleep(1000);
						driver.findElement(By.cssSelector("#loginbutton")).click();
						System.out.println("BOOKWORM_-----------------------------------LOGGED IN----- 100024433954363");
						//break loop
						isPresent = false;
					}
				
				}
	
				//go search
				driver.get(socialgroup + "/search/?query=" + groupsearch + "&epa=SEARCH_BOX");
				System.out.println("BOOKWORM_-------------------------" + socialgroup + "/search/?query=" + groupsearch + "&epa=SEARCH_BOX");
				//filter 2019
				
				isPresent = true;
				for(int j=0; isPresent; j++  ) {
					if (driver.findElements(By.xpath("//*[starts-with(@class,'_4f3b')]")).size()>0)
					{	
						System.out.println("BOOKWORM_--------------------------FILTER---------2019");
						driver.findElement(By.xpath("//*[starts-with(@class,'_4f3b')]")).click();
					
						//break loop
						isPresent = false;
					}
				}
				
				//scroll down 
				for (int i=0; i < 2; i++)
				{
					js.executeScript("window.scrollBy(0,1500)"); 
					System.out.println("BOOKWORM_scrolldown----------------------TIME: "+(i+1));
					Thread.sleep(3000);
				}
				
				
				//get post url
				//empty array
				posturl = new ArrayList<>();
				//loop until found
				isPresent = true;
				for(int i=0; isPresent; i++  ) {
					if (driver.findElements(By.xpath("//*[starts-with(@class,'_lie')]")).size()>0) {
						//save all post url
						//goto each url save comment
						List<WebElement> urlpostlist2 = driver.findElements(By.xpath("//*[starts-with(@class,'_lie')]"));
						Thread.sleep(2000);
						System.out.println("BOOKWORM_ ------TOTAL RECORDS-------------: "+urlpostlist2.size());
						for( int k=0; k< urlpostlist2.size(); k++) 
						{
							String urlvar = urlpostlist2.get(k).getAttribute("href").toString();
							Thread.sleep(500);
							posturl.add(urlvar);	
							System.out.println("BOOKWORM_------GET URL#-----" + k + "--------: " + urlvar);						
						}
						//break loop
						isPresent = false;
					}
				}
	
				//get content post and comment
				for(int j=0; j< posturl.size(); j++  ) {
					driver.get(posturl.get(j));
					Thread.sleep(2000);
					System.out.println("BOOKWORM_---OPEN URL#---" + j + "---: " + posturl.get(j));	
					//if image, close image
					if(driver.findElements(By.xpath("//*[starts-with(@class,'_xlt _418x')]")).size() != 0)
					{
					   WebElement elem = driver.findElement(By.xpath("//*[starts-with(@class,'_xlt _418x')]"));
					   int width = elem.getSize().getWidth(); 
					   Actions act = new Actions(driver);
					   act.moveToElement(elem).moveByOffset(0, 0).click().perform();
					}
					
					
					//open each post get comm
					List<WebElement>  commsize = driver.findElements(By.xpath("//*[contains(@class,'_4eek')]"));
					System.out.println("BOOKWORM_------TOTAL COMM -----" + commsize.size());
					if(commsize.size() != 0)
						for(int l=1; l<= commsize.size(); l++  ) 
						{
							String commid = commsize.get(l-1).getAttribute("innerHTML").toString(); //findElement(By.xpath("//*[starts-with(@class,'_6qw4')]")).getAttribute("data-hovercard").toString();
							Thread.sleep(200);
							commid = commid.substring(commid.indexOf("id=") + 3, commid.indexOf("\" href"));
							String commstr = commsize.get(l-1).getText(); //.findElement(By.xpath("//*[starts-with(@class,'_3l3x')]")).getText();
							Thread.sleep(200);
							//String commtime = commsize.get(l-1).findElement(By.xpath("//*[starts-with(@class,'livetimestamp')]")).getAttribute("data-utime").toString();
							Thread.sleep(200);
							System.out.println("BOOKWORM_------COMM #-----" + l);
							
							//delete \n
							commstr = commstr.replace("\n", "").replace("\r", "");
							commstr = commstr.replaceAll("\\r|\\n", "");
							//checking victim
							crawl_gettok("http://45.118.145.34:3000/api/tok", "POST", "{\"stringsample\": \""+commstr+"\"}");
							Thread.sleep(3000);
							
							//if found, post AD
							if(numres != 0) {
								//postAD(commid)
								
								System.out.println("BOOKWORM_------COMM #-----" + l + "--------: uid " + commid + "\n" + commstr);
								String ADcontent = adcontent;
								
								//call AWS SNS
								crawl_getpost("http://45.118.145.34:3000/api/sms", "POST", "{\"messageSMS\": \""+adcontent+"\",\"topicSMS\": \"arn:aws:sns:ap-southeast-1:281982043102:alertsms\"}");
								System.out.println("-------------SENDING AD to that CUSTOMER.");
								/*
								//post to wall
								//loop until found
								isPresent = true;
								for(int m=0; isPresent; m++  ) {
									System.out.println("BOOKWORM_------FINDING----" + m);
									if(driver.findElements(By.xpath("//*[contains(@class,'_1mf')]")).size() != 0) {
										driver.findElement(By.xpath("//*[contains(@class,'_1mf')]")).clear();
										driver.findElement(By.xpath("//*[contains(@class,'_1mf')]")).sendKeys(ADcontent);
										Thread.sleep(500);
										driver.findElement(By.xpath("//*[contains(@class,'_1mf')]")).sendKeys(Keys.ENTER); 							
										Thread.sleep(200);
										isPresent = false;
									}
								}
								*/
							}
						}
				}
		
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
public class jsonpostresponse2 {
	   public int status;
	   public int result;
}
public class jsonpostresponse {
	   public int status;
	   public resultString result;
}
public class resultString {
    public List<Item> Items;
    public int Count;
    public int ScannedCount;
}     
public class Item {
	public int csid;
	public String socialgroup;
	public String adcontent;
	public String groupsearch;
	public String status;
	public String socialurl;
	public String patternmatch;
	public String topicsms;
	public String assigneephone;
}
public void crawl_gettok(String urlstr, String method, String json) throws InterruptedException, IOException {
	try
	{	
		
		String jsonOutputstatus = jsonpost(urlstr, method, json);
		Thread.sleep(1000);
		
		//jsonOutputstatus = jsonOutputstatus.substring(jsonOutputstatus.indexOf("result:") + 7, jsonOutputstatus.length()); 
		jsonpostresponse2 resjson = gson.fromJson(jsonOutputstatus, jsonpostresponse2.class);
		//System.out.println("-------------JSON-----" + resjson.result);
		
		numres = resjson.result;
		if(numres == 1)
			System.out.println("-------------GET A POTENTIAL CUSTOMER !!!!!!");
	}
	catch (Exception e){
		//System.out.println("IOE: "+e);
	}
}
public void crawl_getpost(String urlstr, String method, String json) throws InterruptedException, IOException {
	try
	{	
		String jsonOutputstatus = jsonpost(urlstr, method, json);
		Thread.sleep(1000);
		
			jsonpostresponse resjson = gson.fromJson(jsonOutputstatus, jsonpostresponse.class);
			System.out.println("-----GET STATUS-----" + numres);
			socialgroup = resjson.result.Items.get(0).socialgroup;
			adcontent = resjson.result.Items.get(0).adcontent;
			groupsearch = resjson.result.Items.get(0).groupsearch;
			patternmatch = resjson.result.Items.get(0).patternmatch;
			topicsms = resjson.result.Items.get(0).topicsms;
			assigneephone = resjson.result.Items.get(0).assigneephone;
			
			if(resjson.result.Items.get(0).status != "0")
				status = true;
			else
				status = false;
	}
	catch (Exception e){
		//System.out.println("IOE: "+e);
	}
}
public static boolean isNumeric(String string) 
{
  try
    {
      double d = Double.parseDouble(string);
    }
    catch(NumberFormatException e)
    {
      return false;
    }
    return true;
  
}
public String jsonpost(String urlpost, String method, String json) throws InterruptedException, IOException {
    HttpClient httpclient = new DefaultHttpClient();
    HttpPost httppost = null;
    HttpGet httpget = null;
    
    //System.out.println("-----JSON-----" + json);
    
    StringEntity requestEntity = new StringEntity(
    		json,
    	    ContentType.APPLICATION_JSON);

    
    String strresponse = "";
    HttpResponse response = null;
    //jsonpostresponse resjson = null;
    try {
        if (method == "POST")
        {
        	httppost = new HttpPost(urlpost);
        	httppost.setEntity(requestEntity);
        	response = httpclient.execute(httppost);
    	}
        else if (method == "GET")
        {	
        	httpget = new HttpGet(urlpost);
        	response = httpclient.execute(httpget);
        }
        	// Execute HTTP Post Request
        InputStream inputStream = response.getEntity().getContent(); //Get the data in the entity
        //Reader reader = new InputStreamReader(source);
        
        BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder stringbuilder = new StringBuilder();
 
        String currentline = null;
        
        try {
            while ((currentline = bufferedreader.readLine()) != null) {
            	stringbuilder.append(currentline + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
	    // Here is the resulting string
        strresponse = stringbuilder.toString();

        inputStream.close();  

        //strresponse = "OK";
        //System.out.println("---------------------------JSON OUT: "+ strresponse);
    } catch (ClientProtocolException e) {
        // TODO Auto-generated catch block
        System.out.println("CPE"+e);
    } catch (IOException e) {
        // TODO Auto-generated catch block
        //System.out.println("IOE"+e);
    }
	return strresponse;
}	

public void postAD(String uid) throws IOException, InterruptedException{
	try {

	} catch (Exception e) {
		e.printStackTrace();
	}
}

@AfterTest public void afterTest() {
		driver.quit();
	}
}

