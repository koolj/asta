package com.kjsparkhttp.spark

import com.kjsparkhttp.util.AppConfig
import org.apache.spark.sql.SparkSession

/**
  * Created by KoolJ@TesterPRO.org on Sep 14, 2018.
  * Creates one SparkSession which is shared and reused among multiple HttpRequests
  */
object SparkFactory {

    val sparkobj = SparkSession
      .builder()
      .appName(AppConfig.sparkAppName)
      .master(AppConfig.sparkMaster)
      .getOrCreate
      //.config("spark.sql.warehouse.dir", "target/spark-warehouse")

    //set new runtime options
    sparkobj.conf.set("spark.sql.shuffle.partitions", 6)
    sparkobj.conf.set("spark.executor.memory", "2g")
    sparkobj.conf.set("spark.sql.parquet.binaryAsString", "true")
    sparkobj.conf.set("parquet.enable.dictionary","true")
    //get all settings
    // val configMap:Map[String, String] = sparkobj.conf.getAll()

    val sc = sparkobj.sparkContext
    val sparkConf = sc.getConf
    import sparkobj.implicits._

    //load to rdd
    //val rdd = sc.read.parquet("data/2v.csv")

    //load from parquet

    //val dfpost = df.select("postcontent").as[String]
    //dfpost.show(50,false)


    //load csv to df
    //val df = sparkobj.read.csv("...csv")

    //get data by value
    // df.filter("_c2 == 84983308279").show()
    //("_c0", "_c1", when("_c0" == "1491451285")).show()  //l //719990078
    // println(s"DF----------------------------------------------------------------"+"\n")
    //df.show(50,false)

}
