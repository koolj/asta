package com.kjsparkhttp.web

import com.kjsparkhttp.spark.SparkFactory
import com.kjsparkhttp.spark.SparkFactory.sparkobj
import org.apache.spark.sql.Dataset
import org.mortbay.util.ajax.JSON

/**
  * Created by KoolJ@TesterPRO.org on Sep 14, 2018.
  * Service class computing the value for route bindings "/activeStreams" and "/count" respectively.
  */
object HttpService {

  val sc = SparkFactory.sc

  // getp
  //val df = sparkobj.read.parquet("pq1k_1527071417176")
  //val dfstr = println(df.show(1))
  val df = sparkobj.read.csv("p.csv")


  def getp(uid: Int): String = {
    var dfstr = df.select("_c2").filter("_c1 == " + "'" + uid + "'").collect().mkString

    if (dfstr == "")
       dfstr = "NA"
    else
      dfstr = dfstr.substring(1, dfstr.length - 1)

    return dfstr
  }

  def func2(): String =  "Yes, it is koolj.2"

  // To server http://host:port/activeStreams route binding
  // Returns how many streams are active in sparkSession currently
  def activeStreamsInSparkContext(): Int = SparkFactory.sparkobj.streams.active.length
}
