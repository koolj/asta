import akka.http.scaladsl.settings.ServerSettings
import com.kjsparkhttp.util.AppConfig
import com.kjsparkhttp.web.WebServer
import com.typesafe.config.ConfigFactory

/**
  * Created by KoolJ@TesterPRO.org on Sep 14, 2018.
  */
object MainApp extends App {

  // init config params from cmd-line args
  AppConfig.parse(this.args.toList)

  // Starting the server
  WebServer.startServer("localhost", AppConfig.akkaHttpPort, ServerSettings(ConfigFactory.load))

  println(s"Server online at http://localhost:", AppConfig.akkaHttpPort, "/")
}
