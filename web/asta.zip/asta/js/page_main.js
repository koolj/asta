//(c) Copyright 2018 by TesterPRO. All rights reserved.
//Created by KoolJ/Pham Tuan Anh.

var jsonsamp = {
friends:[
  {
    avatar:"./imgs/fm.jpg",
    dname:"John Pham aaaaa",
    domains:[],
    uid:"719990076",
    uname:"",
    gender:"Nữ",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Nam",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/fm.jpg",
    dname:"John Pham 2",
    domains:[],
    uid:"719990077",
    uname:"",
    gender:"Nữ",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Nam",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/m.jpg",
    dname:"John Pham 3",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nam",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Bar sàn, gái xinh, phượt, đồ ăn",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/m.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nam",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Bar sàn, gái xinh, phượt, đồ ăn",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/fm.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nữ",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Nam",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/m.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nam",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Bar sàn, gái xinh, phượt, đồ ăn",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/m.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nam",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Bar sàn, gái xinh, phượt, đồ ăn",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/fm.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nữ",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Nam",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/fm.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nữ",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Nam",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/fm.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nữ",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Nam",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/fm.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nữ",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Nam",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/m.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nam",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Bar sàn, gái xinh, phượt, đồ ăn",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/m.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nam",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Bar sàn, gái xinh, phượt, đồ ăn",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/m.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nam",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Bar sàn, gái xinh, phượt, đồ ăn",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/m.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nam",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Bar sàn, gái xinh, phượt, đồ ăn",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/fm.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nữ",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Nam",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/fm.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nữ",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Nam",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/m.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nam",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Bar sàn, gái xinh, phượt, đồ ăn",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/m.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nam",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Bar sàn, gái xinh, phượt, đồ ăn",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/fm.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nữ",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Nam",
    pn:"84*****79"
  },
  {
    avatar:"./imgs/m.jpg",
    dname:"John Pham",
    domains:[],
    uid:"719990078",
    uname:"",
    gender:"Nam",
    age:"25-30",
    income:"300000000",
    live:"Hanoi, Vietnam",
    from:"Hai Phong, Vietnam",
    job:"Nam",
    info:"President at HP.FTU - Hội sinh viên Hải Phòng Đại học Ngoại thương\nWorks at Club de Français de l'ESCE - CLB Tiếng Pháp ĐH Ngoại Thương CFE\nStudies Kinh tế quốc tế at Foreign Trade University\nWent to THPT Chuyên Trần Phú\nLives in Hanoi, Vietnam\nFrom Hai Phong, Vietnam",
    nextexp:"Giầy, đồng hồ, kính, du lịch Nam Cát Tiên",
    hobby:"Bar sàn, gái xinh, phượt, đồ ăn",
    pn:"84*****79"
    
  }
]
};

function addfriend(){
  $(".scrollbar-inner.scroll-content.scroll-scrolly_visible").empty();
  for (var i =0; i < jsonsamp.friends.length; i++){
    html_value_f = `<table class="tableelement" id="itemmem" name="`
    +jsonsamp.friends[i].uid+`"><tr><th style="width:40px"><img src="`
    + jsonsamp.friends[i].avatar +`" class="img-responsive img-circle" style="width:100%" alt="avatar"><div class="small"><br> <small>`
    + jsonsamp.friends[i].dname.substring(0,2) + "*****" + jsonsamp.friends[i].dname.substring(jsonsamp.friends[i].dname.length - 2,jsonsamp.friends[i].dname.length)
    +` </small></div></th><th style="width:120px"><div id="chartContainer`+i+`" style="display:block;"></div><script>
 function chart1() {
     var chart = new CanvasJS.Chart("chartContainer`+i+`",
    {
      axisX: {
       maximum: 85,
       gridThickness: 0.1,
       labelFontColor: "#c1c1c1",
       tickColor: "#c1c1c1",
       lineColor: "#c1c1c1"
      },
      axisY: {
       gridThickness: 0.1,
       labelFontColor: "#c1c1c1",
       tickColor: "#c1c1c1",
       lineColor: "#c1c1c1"
      },
      backgroundColor:"transparent",  

      legend:{
        verticalAlign: "bottom",
        horizontalAlign: "left"

      },
      data: [
      {
        type: "bubble",
        legendMarkerType: "circle",
     dataPoints: [
    // { x: 64.8, y: 2.66, z:12074.4 , name: "India"},
   //  { x: 73.1, y: 1.61, z:13313.8, name: "China"},
     { x: 78.1, y: 2.00, z:306.77, name: "US" },
     { x: 68.5, y: 2.15, z: 237.414, name: "Indonesia"},
     { x: 72.5, y: 1.86, z: 193.24, name: "Brazil"},
     { x: 76.5, y: 2.36, z: 112.24, name: "Mexico"},
     { x: 50.9, y: 5.56, z: 154.48, name: "Nigeria"},
     { x: 68.6, y: 1.54, z:141.91, name: "Russia" },

     { x: 82.9, y: 1.37, z:127.55, name: "Japan" },
     { x: 79.8, y: 1.36, z:81.90, name:"Australia" },
     { x: 72.7, y: 2.78, z: 79.71, name: "Egypt"},
     { x: 80.1, y: 1.94, z:61.81, name:"UK" },
     { x: 55.8, y: 4.76, z: 39.24, name: "Kenya"},
     { x: 81.5, y: 1.93, z:21.95, name:"Australia" },
     { x: 68.1, y: 4.77, z: 31.09, name: "Iraq"},
     { x: 47.9, y: 6.42, z: 33.42, name: "Afganistan"},
     { x: 50.3, y: 5.58, z: 18.55, name: "Angola"}
     ]
   }
   ]
 });

chart.render();
};
    
    chart1();</script></th>
    <th><div class="small"  id="ifi" name ="`
    +jsonsamp.friends[i].gender + `\n-------------------\n `
    +jsonsamp.friends[i].age + `\n-------------------\n `
    +jsonsamp.friends[i].income + `\n-------------------\n `
    +jsonsamp.friends[i].info + `\n-------------------\n `
    + jsonsamp.friends[i].nextexp +`\n-------------------\n `
    + jsonsamp.friends[i].hobby +`\n-------------------\n `+
    `" style="padding: 5px;font-size: 10px;font-style: normal; color: #c1c1c1; display:block;">
    `+ jsonsamp.friends[i].gender +`<br>
    `+ jsonsamp.friends[i].age +`<br>
    Thu nhập dự kiến: `+ jsonsamp.friends[i].income +`<br>
    `+ jsonsamp.friends[i].from +`<br>
    `+ jsonsamp.friends[i].info.substring(0, 60) + ` ...<br>
    Dự kiến chi tiêu : `+ jsonsamp.friends[i].nextexp.substring(0, 30) + ` ...<b><a style="color:Tomato;">Click để xem thêm.</a></b><br>
    Sở thích : `+ jsonsamp.friends[i].hobby.substring(0, 30) + ` ...<br>
    </div></th>
    <th><div>
    <a class="fbi" href="#" name="m.me/`+ jsonsamp.friends[i].uid +`"><img src="./imgs/fbi.png" class="img-responsive" style="height: 34px" alt="fb"></a> 
    <a class="zaloi" href="#" name="chat.zalo.me/`+ jsonsamp.friends[i].pn +`"><img src="./imgs/zaloi.png" class="img-responsive" style="height: 34px" alt="za"></a> 
    <a class="smsi" href="#" name="sms: `+ jsonsamp.friends[i].pn +`"><img src="./imgs/smsi.png" class="img-responsive" style="height: 36px" alt="sms"></a> 
    <a class="phi" href="#" name="call: `+ jsonsamp.friends[i].pn +`"><img src="./imgs/phonei.png" class="img-responsive" style="height: 40px" alt="sms"></a> 
    </div>
    </th><tr></table>`;

    $(".scrollbar-inner").append(html_value_f);
    console.log("add------------------"+jsonsamp.friends[i].uid);
  }
  $('.scrollbar-inner').scrollbar();
  
  /*  
  $(".tableelement").click(function(e){
    alert(e.currentTarget.attributes.name.value);
  });
  */
  $(".small").click(function(e){
    alert(e.currentTarget.attributes.name.value);
  });
  $(".fbi").click(function(e){
    alert(e.currentTarget.attributes.name.value);
  });
    
  $(".zaloi").click(function(e){
    alert(e.currentTarget.attributes.name.value);
  });
  $(".smsi").click(function(e){
    alert(e.currentTarget.attributes.name.value);
  });
  $(".phi").click(function(e){
    alert(e.currentTarget.attributes.name.value);
  });

};



$(".loading").hide();



//add testdata
$(document).ready(function () {
    
  $("#mappart").hide();
  $("#termpart").hide();
  $(".AcknowledgeInnerDiv").hide();
  $("#leftpart").show();
  $("#rightpart").show();
  $("#apppart").hide();  
  addfriend();

});
